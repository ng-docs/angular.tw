export class Customer {
  name = '';
}
